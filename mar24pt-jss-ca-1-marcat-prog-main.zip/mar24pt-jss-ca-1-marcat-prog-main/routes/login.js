var express = require('express');
var router = express.Router();
const passport = require('./auth');

// GET login page
router.get('/login', (req, res) => {
    res.render('login', { error: req.flash('error') });
});

// POST login request
router.post('/login', passport.authenticate('local', {
    successRedirect: '/memes', 
    failureRedirect: '/login', 
    failureFlash: true 
}));

// Logout route
router.get('/logout', (req, res, next) => {
    req.logout(function(err) {
        if (err) return next(err);
        res.redirect('/login');
    });
});

module.exports = router;