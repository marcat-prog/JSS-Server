let memesCache = []; // Store memes in memory
let hasFetchedMemes = false;

var express = require('express');
var router = express.Router();
const axios = require('axios');
const config = require('../config.json'); // Load config 

// Fetch memes when server starts and ensure they are fetched and stored once
async function fetchMemes() {
    if (!hasFetchedMemes) {
        try {
            const response = await axios.get(config.ApiUrl);
            if (response.data && Array.isArray(response.data.memes)) { // Check if response.data.data exists and is an array
                memesCache = response.data.memes.slice(0, 20);
                console.log('Memes loaded successfully.');
                hasFetchedMemes = true;
            } else {
                console.error('Error: API response does not contain an array of memes in the expected format.');
                console.error('Response data:', response.data);
            }
        } catch (error) {
            console.error('Error fetching memes:', error);
        }
    }
}
// Call function to fetch memes when server starts
fetchMemes();

// Middleware to check if user is authenticated
function isAuthenticated(req, res, next) {
    if (req.isAuthenticated()){
        return next();
    }
    res.redirect('/login'); // Redirect guest users to login page
}

// Route to display memes list (everyone can access)
router.get('/', async function (req, res) {
    await fetchMemes(); // Ensure memes are fetched before rendering

    const searchQuery = req.query.search ? req.query.search.toLowerCase() : null;
    let filteredMemes = memesCache;

    if (searchQuery) {
        filteredMemes = memesCache.filter(meme => meme.name.toLowerCase().includes(searchQuery));
    }

    const viewedMemes = req.session.viewedMemes || [];

    // Add a viewedMeme flag to each meme
    filteredMemes = filteredMemes.map(meme => {
        const isViewed = viewedMemes.includes(meme.id.toString());
        console.log('Meme ID:', meme.id, 'Viewed:', isViewed); // <--- HERE
        return {
            ...meme,
            viewedMeme: isViewed
        };
    });

    console.log('Session Viewed Memes:', req.session.viewedMemes); 
    res.render('memes', {
        memes: filteredMemes,
        searchQuery: req.query.search || '',
        user: req.user, // Pass user object
        isAuthenticated: req.isAuthenticated() // Explicitly pass authentication status
    });
});

// Route to display meme details (ONLY for logged-in users) - Handles GET request
router.get('/:id', isAuthenticated, async function (req, res) {
    await fetchMemes(); // Ensure memes are fetched

    const memeId = req.params.id;
    const meme = memesCache.find(m => m.id == memeId); // Find the meme

    if (!meme) {
        return res.status(404).send('Meme not found');
    }

    if (!req.session.viewedMemes) {
        req.session.viewedMemes = [];
    }

    if (!req.session.viewedMemes.includes(memeId)) {
        req.session.viewedMemes.push(memeId);
    }

    

    res.render('memeDetails', {
        meme: meme,
        user: req.user || null
    });
});

// Route to display meme details (ONLY for logged-in users) - Handles POST request
router.post('/details', isAuthenticated, async function (req, res) {
    await fetchMemes(); // Ensure memes are fetched

    const memeId = req.body.memeId;
    const meme = memesCache.find(m => m.id == memeId); // Find the meme

    if (!meme) {
        return res.status(404).send('Meme not found');
    }

    if (!req.session.viewedMemes) {
        req.session.viewedMemes = [];
    }

    if (!req.session.viewedMemes.includes(memeId)) {
        req.session.viewedMemes.push(memeId);
    }

    res.render('memeDetails', {
        meme: meme,
        user: req.user || null
    });
});

module.exports = router;