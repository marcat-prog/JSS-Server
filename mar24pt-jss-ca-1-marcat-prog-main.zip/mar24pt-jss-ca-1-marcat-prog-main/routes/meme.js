var express = require('express');
var router = express.Router();
const axios = require('axios');
const config = require('../config.json'); // to load API URL from config file

// Store the meme data so it doesn't need to be fetched again on page refresh
let memeData = null;

router.get('/:id', async function (req, res, next) {
    const memeId = req.params.id;

    if (!memeData) {
        try {
            const response = await axios.get(config.ApiUrl);
            memeData = response.data; // Store meme data
            console.log(memeData);
        } catch (err) {
            return next(err);
        }
    }
 const meme = memeData.find(m => m.id == memeId); // Find meme by ID

  if (!meme) {
    return next(new Error('Meme not found'));
  }

  res.render('meme', { meme: meme }); // Pass the meme data to the meme.ejs view
});

module.exports = router;
