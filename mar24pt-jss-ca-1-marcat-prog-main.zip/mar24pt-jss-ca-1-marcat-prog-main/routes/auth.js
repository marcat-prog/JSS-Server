const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;

// Load users from users.json
const users = require('../users.json');

// Configure Passport Local Strategy
passport.use(new LocalStrategy((username, password, done) => {
    const user = users.find(user => user.username === username);
    if (!user) {
        return done(null, false, { message: 'Incorrect username' });
    }
    if (user.password !== password) {
        return done(null, false, { message: 'Incorrect password' });
    }
    return done(null, user);
}));

// Serialize user (store user ID in session)
passport.serializeUser((user, done) => {
    done(null, user.id);
});

// Deserialize user (retrieve user data from session)
passport.deserializeUser((id, done) => {
    const user = users.find(user => user.id === parseInt(id)); // Ensure ID is treated as a number
    done(null, user);
});

module.exports = passport;