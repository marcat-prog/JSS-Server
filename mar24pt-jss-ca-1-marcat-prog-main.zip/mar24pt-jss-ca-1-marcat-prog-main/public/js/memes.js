document.addEventListener('DOMContentLoaded', () => {
    const detailsButtons = document.querySelectorAll('.btn-details');

    detailsButtons.forEach(button => {
        button.addEventListener('click', function() {
            const memeId = this.getAttribute('data-meme-id');

            // Create a form dynamically
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '/memes/details';

            // Create an input element for memeId
            const memeIdInput = document.createElement('input');
            memeIdInput.type = 'hidden';
            memeIdInput.name = 'memeId';
            memeIdInput.value = memeId;

            // Append the input to the form
            form.appendChild(memeIdInput);

            // Append the form to the body (it doesn't need to be visible)
            document.body.appendChild(form);

            // Submit the form
            form.submit();
        });
    });
});